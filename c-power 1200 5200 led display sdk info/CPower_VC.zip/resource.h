//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CPower_VC.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDR_MAINFRAME                   128
#define IDD_CPOWER_VC_DIALOG            129
#define IDC_RADIO1                      1000
#define IDC_RADIO2                      1001
#define IDC_BTN_SPLIT_WND               1002
#define IDC_EDIT1                       1003
#define IDC_EDIT2                       1004
#define IDC_BTN_PLAY_PROGRAM            1005
#define IDC_EDIT_PRONO                  1006
#define IDC_BTN_SEND_TEXT               1007
#define IDC_EDIT_TEXT                   1008
#define IDC_BTN_MAKE_PROGRAM            1009
#define IDC_BTN_MAKE_PLAYBILL           1010
#define IDC_BTN_SEND_PICT               1011
#define IDC_BTN_SEND_STATIC_TEXT        1012
#define IDC_SEND_CLOCK                  1013
#define IDC_BTN_SET_TIME                1014
#define IDC_BTN_UPLOAD                  1015
#define IDC_PORT                        1044
#define IDC_BAUDRATE                    1045
#define IDC_ID                          1046
#define IDC_PORT2                       1047
#define IDC_IPADDR                      1048
#define IDC_IDCODE                      1049
#define IDC_EDIT_PICT                   1050
#define IDC_EDIT_STATIC_TEXT            1051
#define IDC_ID2                         1052

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
