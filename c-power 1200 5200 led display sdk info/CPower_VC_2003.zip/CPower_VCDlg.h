// CPower_VCDlg.h : ͷ�ļ�
//

#pragma once
#include "afxwin.h"


// CPower_VCDlg �Ի���
class CPower_VCDlg : public CDialog
{
// ����
public:
	CPower_VCDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_CPOWER_VC_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedRadio1();
	afx_msg void OnBnClickedRadio2();
	afx_msg void OnBnClickedBtnSplitWnd();
	afx_msg void OnBnClickedBtnSendText();
	afx_msg void OnBnClickedBtnSendPict();
	afx_msg void OnBnClickedBtnSendStaticText();
	afx_msg void OnBnClickedSendClock();
	afx_msg void OnBnClickedBtnSetTime();
	afx_msg void OnBnClickedBtnPlayProgram();

private:
	void InitComm(); //��ʼ��ͨѶ����
	void EnableCtrl() ;
	void GetSplitWnd( RECT* rcWins );

private:
	int m_nCommType;

	CComboBox m_cmbPort;
	CComboBox m_cmbBaudrate;
	CComboBox m_cmbCardID;
	DWORD m_dwIPAddr;
	DWORD m_dwIDCode;
	int m_nPort;
	int m_nTimeOut;
	int m_nWidth;
	int m_nHeight;
	CComboBox m_cmbWndNo;


public:
	int m_nProNo;
};
